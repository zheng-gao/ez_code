# Tree Node
DATA_NAME = "data"
LEFT_NAME = "left"
RIGHT_NAME = "right"

# Printer
LEFT_WING = "─"
RIGHT_WING = "─"
LEFT_WING_HEAD = "┌"
RIGHT_WING_HEAD = "┐"
LEFT_WING_TAIL = "("
RIGHT_WING_TAIL = ")"
